<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ruangs', function (Blueprint $table) {
            $table->bigIncrements('id_ruang');
            $table->string('nama_ruang');
            $table->integer('kapasitas');
            $table->string('fasilitas');
            $table->string('dimensi');
            $table->unsignedBigInteger('id_gedung')->index('id_gedung');
            $table->boolean('status')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ruangs');
    }
};
