<h2>Informasi Akun Mahasiswa</h2>
<p>Halo <?php echo e($name); ?>,</p>
<p>Selamat! Akun mahasiswa Anda telah Didaftarkan ke sistem kami dengan detail sebagai berikut:</p>
<ul>
    <li>Name: <?php echo e($name); ?></li>
    <li>NIM: <?php echo e($nim); ?></li>
    <li>Email: <?php echo e($email); ?></li>
    <li>Password: <?php echo e($password); ?></li>
</ul>
<p> <b>Silahkan menunggu konfirmasi dari kami untuk dapat menggunakan akun anda.</b></p><?php /**PATH /home/babozzkaa/Project/Backend-Port/resources/views/emails/mahasiswa/info-akun.blade.php ENDPATH**/ ?>