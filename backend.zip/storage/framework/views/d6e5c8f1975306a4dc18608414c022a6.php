<h2>Informasi Akun Dosen</h2>
<p>Halo <?php echo e($name); ?>,</p>
<p>Berikut adalah informasi akun dosen Anda:</p>
<ul>
    <li>Nama: <?php echo e($name); ?></li>
    <li>Email: <?php echo e($email); ?></li>
    <li>Password: <?php echo e($password); ?></li>
</ul>
<p>Silakan login menggunakan kredensial di atas.</p><?php /**PATH /home/babozzkaa/Project/Backend-Port/resources/views/emails/dosen/info-akun.blade.php ENDPATH**/ ?>