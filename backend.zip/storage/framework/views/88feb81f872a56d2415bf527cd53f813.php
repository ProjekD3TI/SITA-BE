<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Invoice Peminjaman BHP - <?php echo e($peminjaman->id_peminjaman_bhp); ?></title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            font-size: 12px;
            color: #000;
            margin: 40px;
            line-height: 1.5;
        }

        h2 {
            text-align: center;
            font-size: 20pt;
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .subtitle {
            text-align: center;
            font-size: 12px;
            margin-bottom: 30px;
            color: #000;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }

        .info-table td {
            padding: 6px 4px;
            vertical-align: top;
        }

        .label {
            width: 160px;
            font-weight: bold;
        }

        .section-title {
            font-size: 13px;
            font-weight: bold;
            border-bottom: 1px solid #000;
            padding-bottom: 4px;
            margin-bottom: 10px;
        }

        .item-detail {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
        }

        .signature-container {
            display: table;
            width: 100%;
            margin-top: 5px;
            border-collapse: separate;
            border-spacing: 10px;
        }

        .signature-box {
            display: table-cell;
            width: 50%;
            /* border: 1px solid #000; */
            padding: 15px;
            height: 120px;
            text-align: center;
            vertical-align: top;
            box-sizing: border-box;
        }

        .signature-title {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .signature-date {
            margin-bottom: 40px;
        }

        .signature-name {
            font-weight: bold;
            border-bottom: 1px solid #000;
            padding-bottom: 5px;
            margin-top: 50px;
        }

        .qr-code {
            position: absolute;
            top: 40px;
            left: 35px;
            width: 100px;
        }

        @media print {
            body {
                margin: 0;
            }
            .qr-code {
                border: none;
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="qr-code">
        <?php if(!empty($peminjaman->qr_code_path) && file_exists(public_path('storage/bhp/peminjaman/qrcode/' . $peminjaman->qr_code_path)) && is_file(public_path('storage/bhp/peminjaman/qrcode/' . $peminjaman->qr_code_path))): ?>
            <img src="<?php echo e(public_path('storage/bhp/peminjaman/qrcode/' . $peminjaman->qr_code_path)); ?>" width="120">
        <?php else: ?>
            <p>QR Code tidak ditemukan</p>
        <?php endif; ?>
    </div>

    <h2>Invoice Peminjaman BHP</h2>
    <div class="subtitle"><?php echo e($tanggalPinjam); ?></div>

    <table class="info-table">
        <tr>
            <td class="label">Nama Peminjam</td>
            <td>:
                <?php echo e(collect(explode(' ', $peminjaman->nama_peminjam))
                        ->map(function($word, $i) {
                            if ($i < 2) return $word;
                            return mb_substr($word, 0, 1) . '.';
                        })
                        ->implode(' ')); ?>

            </td>
        </tr>
        <tr>
            <td class="label">Nomor Induk</td>
            <td>: <?php echo e($peminjaman->ni_peminjam); ?></td>
        </tr>
        <tr>
            <td class="label">Nomor Telepon</td>
            <td>: <?php echo e($peminjaman->no_telp ?? '-'); ?></td>
        </tr>
        <tr>
            <td class="label">Keperluan</td>
            <td>: <?php echo e($peminjaman->kegunaan); ?></td>
        </tr>
    </table>

    <div class="section-title">Detail Barang Habis Pakai</div>

    <table class="info-table">
        <tr>
            <td class="label">Nama Barang</td>
            <td>: <?php echo e($bhp->nama_bhp); ?></td>
        </tr>
        <tr>
            <td class="label">Jumlah Peminjaman</td>
            <td>: <?php echo e($peminjaman->jumlah_penggunaan); ?> unit</td>
        </tr>
    </table>

    <p style="text-align: right; margin-right: 30px;">Surakarta, <?php echo e(now()->locale('id')->translatedFormat('d F Y')); ?></p>
    <p style="text-align: center;">Mengetahui</p>
    <div class="signature-container">
        <div class="signature-box">
            <div class="signature-title">Admin</div>
            <div class="signature-name">
                <?php echo e(collect(explode(' ', $peminjaman->created_by))
                        ->take(2)
                        ->implode(' ')); ?>

            </div>
        </div>
        <div class="signature-box">
            <div class="signature-date">Peminjam</div>
            <div class="signature-name">
                <?php echo e(collect(explode(' ', $peminjaman->nama_peminjam))
                        ->take(2)
                        ->implode(' ')); ?>

            </div>
        </div>
    </div>

</body>
</html><?php /**PATH /home/babozzkaa/Project/Backend-Port/resources/views/peminjaman/detail_bhp.blade.php ENDPATH**/ ?>